## GSM8K Accuracy Test files

* `results/gsm8k_[Model name].csv`: the original input/output, ground truth, output answer for each methods.
* `GSM8K_KV_quant_test.py`: scripts for testing on GSM8K