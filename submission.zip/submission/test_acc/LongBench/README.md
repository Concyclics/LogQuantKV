## LongBench Accuracy Test files

* `src/*` : modified LongBench for testing LogQuant
* `results.csv`: summarized result
* `results/[Model]/[KV Method_n-bit_Reserved Length]/[Task].jsonl`: the original outputs of each methods and models
* `*.py`: scripts for summarizing results