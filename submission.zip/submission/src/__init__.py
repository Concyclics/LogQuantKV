# __init__.py

import src.LogQuant

if __name__ == "__main__":
    print("Hello, World!")